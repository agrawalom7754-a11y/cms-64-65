# Customer Management System

A Java Full Stack college mini project for adding and managing customer records.

## Technology stack
- Frontend: HTML, CSS, Vanilla JavaScript
- Backend: Java 21, Spring Boot 3.5, Spring Web, Spring Data JPA, Hibernate
- Database: MySQL
- API documentation: Swagger/OpenAPI
- Testing: JUnit 5, Mockito, MockMvc, H2 for integration tests

## Project layout
- `frontend/` — existing frontend files (kept unchanged)
- `backend/` — Spring Boot REST API
- `backend/database/` — SQL setup and optional sample data

## 1. Prerequisites
Install JDK 21, MySQL Server, MySQL Workbench, and (if you are not using the Maven Wrapper) Maven.

Check Java and Maven in a terminal:
```powershell
java -version
mvn -version
```

## 2. Create the database
Open MySQL Workbench and run:
```sql
CREATE DATABASE IF NOT EXISTS customer_management_db
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
You can also run `backend/database/01-create-database.sql`.

The Spring Boot app creates/updates the `customers` table on startup using JPA.

## 3. Configure database credentials
Open `backend/src/main/resources/application.properties`.
By default, the username is `root` and the password placeholder is `CHANGE_ME`.

Set your actual password locally by either:
- changing `spring.datasource.password` in your local working copy, or
- setting the `DB_USERNAME` and `DB_PASSWORD` environment variables.

Do not commit actual passwords to GitHub. Ensure the database user has permission to access `customer_management_db`.

## 4. Start the backend
Open a terminal in the `backend` directory and run:
```powershell
mvn spring-boot:run
```
If a Maven Wrapper is present, you can instead use:
```powershell
.\mvnw.cmd spring-boot:run
```

The API will run at `http://localhost:8080`.

Swagger UI:
`http://localhost:8080/swagger-ui.html`

API endpoints:
- `GET /api/customers` — list customers
- `GET /api/customers/{id}` — get one customer
- `POST /api/customers` — create customer
- `PUT /api/customers/{id}` — update customer
- `DELETE /api/customers/{id}` — delete customer

Example JSON for POST/PUT:
```json
{
  "fullName": "Aarav Sharma",
  "email": "aarav.sharma@example.com",
  "phone": "9820011122",
  "address": "12 Linking Road, Bandra",
  "city": "Mumbai",
  "status": "ACTIVE"
}
```
Status must be `ACTIVE` or `INACTIVE`.

## 5. Start the frontend
Open the `frontend` folder in VS Code and launch `index.html` with the Live Server extension. The CORS configuration allows common Live Server origins on ports 5500, 5501, and 5502.

The current frontend is intentionally preserved in preview mode. In `frontend/script.js`, change:
```js
USE_MOCK_DATA: true
```
to:
```js
USE_MOCK_DATA: false
```
only after the backend and MySQL are running. Then refresh the frontend. If your Live Server uses another port, add that origin in `CorsConfig.java`, restart the backend, and retry.

## 6. Run tests
From the `backend` directory:
```powershell
mvn test
```
The tests use an in-memory H2 database, so they should not require your local MySQL credentials.

## Notes
- This project is a starter implementation; run and test it in your own environment before submission.
- Keep the frontend and backend running in separate terminals.
- The app is not configured with login/JWT authentication. That is optional and can be added after CRUD functionality is working.
