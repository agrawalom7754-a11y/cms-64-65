"use strict";

/* =====================================================
   1. CONFIGURATION
   Set USE_MOCK_DATA to false when the Spring Boot
   backend is running.
   ===================================================== */
const CONFIG = {
  API_BASE_URL: "http://localhost:8080/api/customers",
  USE_MOCK_DATA: true,   // true = temporary preview data, false = real REST API
  PAGE_SIZE: 8,
};

/* =====================================================
   2. MOCK DATA (PREVIEW ONLY)
   Temporary in-memory data so the UI can be tested
   before the backend exists. It resets on page refresh
   and is NOT saved to any database.
   ===================================================== */
const daysAgo = (n) => new Date(Date.now() - n * 86400000).toISOString();

const mockDb = {
  nextId: 11,
  customers: [
    { id: 1,  fullName: "Aarav Sharma",   email: "aarav.sharma@example.com",  phone: "9820011122", address: "12 Linking Road, Bandra",   city: "Mumbai",    status: "ACTIVE",   createdAt: daysAgo(1) },
    { id: 2,  fullName: "Priya Nair",     email: "priya.nair@example.com",    phone: "9845012345", address: "45 MG Road",                city: "Bengaluru", status: "ACTIVE",   createdAt: daysAgo(2) },
    { id: 3,  fullName: "Rohan Mehta",    email: "rohan.mehta@example.com",   phone: "9911223344", address: "8 Connaught Place",         city: "Delhi",     status: "INACTIVE", createdAt: daysAgo(4) },
    { id: 4,  fullName: "Sneha Iyer",     email: "sneha.iyer@example.com",    phone: "9splitting".replace("splitting", "840055667"), address: "21 Anna Salai", city: "Chennai", status: "ACTIVE", createdAt: daysAgo(6) },
    { id: 5,  fullName: "Vikram Patil",   email: "vikram.patil@example.com",  phone: "9822334455", address: "77 FC Road",                city: "Pune",      status: "ACTIVE",   createdAt: daysAgo(9) },
    { id: 6,  fullName: "Ananya Reddy",   email: "ananya.reddy@example.com",  phone: "9908877665", address: "5 Banjara Hills",           city: "Hyderabad", status: "INACTIVE", createdAt: daysAgo(14) },
    { id: 7,  fullName: "Karan Singh",    email: "karan.singh@example.com",   phone: "9810099887", address: "19 Sector 17",              city: "Chandigarh",status: "ACTIVE",   createdAt: daysAgo(20) },
    { id: 8,  fullName: "Meera Joshi",    email: "meera.joshi@example.com",   phone: "9833112244", address: "3 Park Street",             city: "Kolkata",   status: "ACTIVE",   createdAt: daysAgo(26) },
    { id: 9,  fullName: "Arjun Desai",    email: "arjun.desai@example.com",   phone: "9898765432", address: "14 CG Road",                city: "Ahmedabad", status: "INACTIVE", createdAt: daysAgo(33) },
    { id: 10, fullName: "Divya Kulkarni", email: "divya.kulkarni@example.com",phone: "9867001122", address: "62 Andheri East",           city: "Mumbai",    status: "ACTIVE",   createdAt: daysAgo(41) },
  ],
};

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const mockApi = {
  async getAll() {
    await delay(400);
    return mockDb.customers.map((c) => ({ ...c }));
  },
  async getById(id) {
    await delay(250);
    const found = mockDb.customers.find((c) => c.id === Number(id));
    if (!found) throw new Error("Customer not found.");
    return { ...found };
  },
  async create(data) {
    await delay(400);
    if (mockDb.customers.some((c) => c.email.toLowerCase() === data.email.toLowerCase())) {
      throw new Error("A customer with this email already exists.");
    }
    const created = { ...data, id: mockDb.nextId++, createdAt: new Date().toISOString() };
    mockDb.customers.push(created);
    return { ...created };
  },
  async update(id, data) {
    await delay(400);
    const index = mockDb.customers.findIndex((c) => c.id === Number(id));
    if (index === -1) throw new Error("Customer not found.");
    const duplicate = mockDb.customers.some(
      (c) => c.id !== Number(id) && c.email.toLowerCase() === data.email.toLowerCase()
    );
    if (duplicate) throw new Error("A customer with this email already exists.");
    mockDb.customers[index] = { ...mockDb.customers[index], ...data };
    return { ...mockDb.customers[index] };
  },
  async remove(id) {
    await delay(300);
    const index = mockDb.customers.findIndex((c) => c.id === Number(id));
    if (index === -1) throw new Error("Customer not found.");
    mockDb.customers.splice(index, 1);
    return null;
  },
};

/* =====================================================
   3. REAL API LAYER (Spring Boot REST, uses fetch)
   Expected JSON for a customer:
   { id, fullName, email, phone, address, city, status, createdAt }
   status is "ACTIVE" or "INACTIVE".
   Errors should return JSON like { "message": "..." }.
   ===================================================== */
async function request(url, options = {}) {
  let response;
  try {
    response = await fetch(url, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
  } catch (err) {
    throw new Error("Cannot reach the server. Check that the backend is running.");
  }

  if (!response.ok) {
    let message = `Request failed (status ${response.status}).`;
    try {
      const body = await response.json();
      if (body && body.message) message = body.message;
    } catch (e) { /* response had no JSON body */ }
    throw new Error(message);
  }

  if (response.status === 204) return null;   // e.g. DELETE with no body
  return response.json();
}

const realApi = {
  getAll:  ()         => request(CONFIG.API_BASE_URL),                                                    // GET    /api/customers
  getById: (id)       => request(`${CONFIG.API_BASE_URL}/${id}`),                                         // GET    /api/customers/{id}
  create:  (data)     => request(CONFIG.API_BASE_URL, { method: "POST", body: JSON.stringify(data) }),    // POST   /api/customers
  update:  (id, data) => request(`${CONFIG.API_BASE_URL}/${id}`, { method: "PUT", body: JSON.stringify(data) }), // PUT /api/customers/{id}
  remove:  (id)       => request(`${CONFIG.API_BASE_URL}/${id}`, { method: "DELETE" }),                   // DELETE /api/customers/{id}
};

const api = CONFIG.USE_MOCK_DATA ? mockApi : realApi;

/* =====================================================
   4. HELPERS
   ===================================================== */
const view = document.getElementById("view");
const pageTitle = document.getElementById("pageTitle");

const state = { customers: [], search: "", status: "ALL", page: 1 };
let renderToken = 0;          // ignores results of outdated async renders
let retryHandler = null;      // used by the "Try again" button

const ICONS = {
  dashboard: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>',
  users:     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
  userCheck: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><polyline points="17 11 19 13 23 9"/></svg>',
  clock:     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
  plus:      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
  edit:      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>',
  trash:     '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>',
  search:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
  menu:      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>',
};
const icon = (name) => ICONS[name] || "";

// Escape text before putting it into HTML (prevents HTML injection)
function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function initials(name) {
  return name.trim().split(/\s+/).slice(0, 2).map((w) => w[0].toUpperCase()).join("");
}

function formatDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return isNaN(d) ? "—" : d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}

function statusBadge(status) {
  const active = status === "ACTIVE";
  return `<span class="badge ${active ? "badge-active" : "badge-inactive"}">${active ? "Active" : "Inactive"}</span>`;
}

function showToast(message, type = "success") {
  const box = document.getElementById("toasts");
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  box.appendChild(toast);
  setTimeout(() => toast.remove(), 3500);
}

function showLoading(text = "Loading...") {
  view.innerHTML = `<div class="card state-box"><div class="spinner"></div><p>${esc(text)}</p></div>`;
}

function showError(message, retry) {
  retryHandler = retry;
  view.innerHTML = `
    <div class="card state-box">
      <h3 class="error-text">Something went wrong</h3>
      <p>${esc(message)}</p>
      <button class="btn btn-primary" data-action="retry">Try again</button>
    </div>`;
}

// Promise-based confirmation dialog
function confirmDialog(title, text, okLabel = "Delete") {
  return new Promise((resolve) => {
    const modal = document.getElementById("confirmModal");
    document.getElementById("confirmTitle").textContent = title;
    document.getElementById("confirmText").textContent = text;
    const ok = document.getElementById("confirmOk");
    const cancel = document.getElementById("confirmCancel");
    ok.textContent = okLabel;
    modal.hidden = false;

    const close = (result) => {
      modal.hidden = true;
      ok.onclick = cancel.onclick = modal.onclick = null;
      document.removeEventListener("keydown", onKey);
      resolve(result);
    };
    const onKey = (e) => { if (e.key === "Escape") close(false); };
    ok.onclick = () => close(true);
    cancel.onclick = () => close(false);
    modal.onclick = (e) => { if (e.target === modal) close(false); };
    document.addEventListener("keydown", onKey);
  });
}

/* =====================================================
   5. DASHBOARD PAGE
   ===================================================== */
async function renderDashboard() {
  const token = ++renderToken;
  showLoading("Loading dashboard...");
  try {
    state.customers = await api.getAll();
  } catch (err) {
    if (token !== renderToken) return;
    return showError(err.message, renderDashboard);
  }
  if (token !== renderToken) return;

  const list = state.customers;
  const total = list.length;
  const active = list.filter((c) => c.status === "ACTIVE").length;
  const weekAgo = Date.now() - 7 * 86400000;
  const recentCount = list.filter((c) => new Date(c.createdAt).getTime() >= weekAgo).length;
  const latest = [...list]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5);

  const recentHtml = latest.length
    ? latest.map((c) => `
        <div class="recent-item">
          <div class="avatar">${esc(initials(c.fullName))}</div>
          <div class="recent-info"><strong>${esc(c.fullName)}</strong><span>${esc(c.email)}</span></div>
          ${statusBadge(c.status)}
          <span class="recent-date">${formatDate(c.createdAt)}</span>
        </div>`).join("")
    : `<div class="state-box"><h3>No customers yet</h3><p>Add your first customer to see it here.</p></div>`;

  view.innerHTML = `
    <div class="page-head">
      <div><h2>Overview</h2><p>A quick summary of your customer records.</p></div>
      <button class="btn btn-primary" data-action="goto" data-target="#/add">${icon("plus")} Add Customer</button>
    </div>

    <div class="stats-grid">
      <div class="card stat-card">
        <div class="stat-icon blue">${icon("users")}</div>
        <div><div class="stat-label">Total Customers</div><div class="stat-value">${total}</div></div>
      </div>
      <div class="card stat-card">
        <div class="stat-icon green">${icon("userCheck")}</div>
        <div><div class="stat-label">Active Customers</div><div class="stat-value">${active}</div></div>
      </div>
      <div class="card stat-card">
        <div class="stat-icon amber">${icon("clock")}</div>
        <div><div class="stat-label">Added in Last 7 Days</div><div class="stat-value">${recentCount}</div></div>
      </div>
    </div>

    <section class="card">
      <div class="card-header">
        <h3>Recently Added Customers</h3>
        <button class="link-btn" data-action="goto" data-target="#/customers">View all</button>
      </div>
      ${recentHtml}
    </section>`;
}

/* =====================================================
   6. CUSTOMER LIST PAGE (search, filter, pagination)
   ===================================================== */
async function renderCustomers() {
  const token = ++renderToken;
  showLoading("Loading customers...");
  try {
    state.customers = await api.getAll();
  } catch (err) {
    if (token !== renderToken) return;
    return showError(err.message, renderCustomers);
  }
  if (token !== renderToken) return;

  view.innerHTML = `
    <div class="page-head">
      <div><h2>Customer Management</h2><p>Search, edit and manage your customers.</p></div>
      <button class="btn btn-primary" data-action="goto" data-target="#/add">${icon("plus")} Add Customer</button>
    </div>
    <section class="card">
      <div class="toolbar">
        <div class="search">
          ${icon("search")}
          <input type="search" id="searchInput" placeholder="Search by name, email or phone" value="${esc(state.search)}">
        </div>
        <select id="statusFilter" aria-label="Filter by status">
          <option value="ALL">All statuses</option>
          <option value="ACTIVE">Active</option>
          <option value="INACTIVE">Inactive</option>
        </select>
      </div>
      <div id="tableArea"></div>
    </section>`;

  const statusFilter = document.getElementById("statusFilter");
  statusFilter.value = state.status;

  document.getElementById("searchInput").addEventListener("input", (e) => {
    state.search = e.target.value;
    state.page = 1;
    renderTable();
  });
  statusFilter.addEventListener("change", (e) => {
    state.status = e.target.value;
    state.page = 1;
    renderTable();
  });

  renderTable();
}

function getFilteredCustomers() {
  const q = state.search.trim().toLowerCase();
  return state.customers.filter((c) => {
    const matchesStatus = state.status === "ALL" || c.status === state.status;
    const matchesSearch =
      !q ||
      c.fullName.toLowerCase().includes(q) ||
      c.email.toLowerCase().includes(q) ||
      String(c.phone).toLowerCase().includes(q);
    return matchesStatus && matchesSearch;
  });
}

function renderTable() {
  const area = document.getElementById("tableArea");
  if (!area) return;

  // Empty list (no customers at all)
  if (state.customers.length === 0) {
    area.innerHTML = `
      <div class="state-box">
        <h3>No customers yet</h3>
        <p>Your customer list is empty. Add your first customer to get started.</p>
        <button class="btn btn-primary" data-action="goto" data-target="#/add">${icon("plus")} Add Customer</button>
      </div>`;
    return;
  }

  const filtered = getFilteredCustomers();

  // No results for the current search/filter
  if (filtered.length === 0) {
    area.innerHTML = `<div class="state-box"><h3>No matching customers</h3><p>Try a different search term or status filter.</p></div>`;
    return;
  }

  const totalPages = Math.max(1, Math.ceil(filtered.length / CONFIG.PAGE_SIZE));
  state.page = Math.min(state.page, totalPages);
  const start = (state.page - 1) * CONFIG.PAGE_SIZE;
  const pageItems = filtered.slice(start, start + CONFIG.PAGE_SIZE);

  const rows = pageItems.map((c) => `
    <tr>
      <td>#${esc(c.id)}</td>
      <td><div class="cell-name"><div class="avatar">${esc(initials(c.fullName))}</div>${esc(c.fullName)}</div></td>
      <td>${esc(c.email)}</td>
      <td>${esc(c.phone)}</td>
      <td>${esc(c.city)}</td>
      <td>${statusBadge(c.status)}</td>
      <td>
        <div class="actions">
          <button class="icon-btn edit" title="Edit" aria-label="Edit ${esc(c.fullName)}" data-action="edit" data-id="${esc(c.id)}">${icon("edit")}</button>
          <button class="icon-btn danger" title="Delete" aria-label="Delete ${esc(c.fullName)}" data-action="delete" data-id="${esc(c.id)}">${icon("trash")}</button>
        </div>
      </td>
    </tr>`).join("");

  area.innerHTML = `
    <div class="table-wrap">
      <table>
        <thead>
          <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>City</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
    <div class="pagination">
      <span>Showing ${start + 1}–${start + pageItems.length} of ${filtered.length}</span>
      <div class="pagination-controls">
        <button class="btn btn-secondary btn-sm" data-action="page" data-page="${state.page - 1}" ${state.page === 1 ? "disabled" : ""}>Previous</button>
        <span>Page ${state.page} of ${totalPages}</span>
        <button class="btn btn-secondary btn-sm" data-action="page" data-page="${state.page + 1}" ${state.page === totalPages ? "disabled" : ""}>Next</button>
      </div>
    </div>`;
}

async function deleteCustomer(id) {
  const customer = state.customers.find((c) => String(c.id) === String(id));
  const name = customer ? customer.fullName : "this customer";
  const confirmed = await confirmDialog(
    "Delete customer?",
    `Are you sure you want to delete ${name}? This action cannot be undone.`
  );
  if (!confirmed) return;

  try {
    await api.remove(id);
    state.customers = await api.getAll();   // reload the list after deleting
    showToast(`${name} was deleted successfully.`, "success");
    renderTable();
  } catch (err) {
    showToast(err.message || "Could not delete the customer.", "error");
  }
}

/* =====================================================
   7. ADD / EDIT FORM PAGE
   ===================================================== */
async function renderForm(id) {
  const token = ++renderToken;
  const isEdit = Boolean(id);
  let customer = { fullName: "", email: "", phone: "", address: "", city: "", status: "ACTIVE" };

  if (isEdit) {
    showLoading("Loading customer...");
    try {
      customer = await api.getById(id);   // pre-fill the form with existing data
    } catch (err) {
      if (token !== renderToken) return;
      return showError(err.message, () => renderForm(id));
    }
    if (token !== renderToken) return;
  }

  view.innerHTML = `
    <div class="page-head">
      <div>
        <h2>${isEdit ? "Edit Customer" : "Add New Customer"}</h2>
        <p>${isEdit ? "Update the customer's details below." : "Fill in the details to create a customer record."}</p>
      </div>
    </div>
    <section class="card form-card">
      <form id="customerForm" class="card-body" novalidate data-id="${isEdit ? esc(customer.id) : ""}">
        <div class="form-grid">
          <div class="field">
            <label for="fullName">Full Name <span class="required">*</span></label>
            <input type="text" id="fullName" name="fullName" value="${esc(customer.fullName)}" placeholder="e.g. Aarav Sharma">
            <div class="field-error" data-error-for="fullName"></div>
          </div>
          <div class="field">
            <label for="email">Email <span class="required">*</span></label>
            <input type="email" id="email" name="email" value="${esc(customer.email)}" placeholder="name@example.com">
            <div class="field-error" data-error-for="email"></div>
          </div>
          <div class="field">
            <label for="phone">Phone <span class="required">*</span></label>
            <input type="tel" id="phone" name="phone" value="${esc(customer.phone)}" placeholder="e.g. 9820011122">
            <div class="field-error" data-error-for="phone"></div>
          </div>
          <div class="field">
            <label for="city">City <span class="required">*</span></label>
            <input type="text" id="city" name="city" value="${esc(customer.city)}" placeholder="e.g. Mumbai">
            <div class="field-error" data-error-for="city"></div>
          </div>
          <div class="field full">
            <label for="address">Address</label>
            <textarea id="address" name="address" placeholder="Street, area, landmark">${esc(customer.address)}</textarea>
            <div class="field-error" data-error-for="address"></div>
          </div>
          <div class="field">
            <label for="status">Status <span class="required">*</span></label>
            <select id="status" name="status">
              <option value="ACTIVE" ${customer.status === "ACTIVE" ? "selected" : ""}>Active</option>
              <option value="INACTIVE" ${customer.status === "INACTIVE" ? "selected" : ""}>Inactive</option>
            </select>
            <div class="field-error" data-error-for="status"></div>
          </div>
        </div>
        <div class="form-actions">
          <button type="button" class="btn btn-secondary" data-action="goto" data-target="#/customers">Cancel</button>
          <button type="submit" class="btn btn-primary" id="submitBtn">${isEdit ? "Update Customer" : "Save Customer"}</button>
        </div>
      </form>
    </section>`;
}

function validateCustomer(data) {
  const errors = {};
  if (!data.fullName) errors.fullName = "Full name is required.";
  else if (data.fullName.length < 2) errors.fullName = "Name must be at least 2 characters.";

  if (!data.email) errors.email = "Email is required.";
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email)) errors.email = "Enter a valid email address.";

  if (!data.phone) errors.phone = "Phone number is required.";
  else if (!/^\+?[0-9][0-9\s-]{8,14}$/.test(data.phone)) errors.phone = "Enter a valid phone number (9–15 digits).";

  if (!data.city) errors.city = "City is required.";
  if (!["ACTIVE", "INACTIVE"].includes(data.status)) errors.status = "Please select a status.";
  return errors;
}

function showFormErrors(form, errors) {
  form.querySelectorAll("[data-error-for]").forEach((el) => (el.textContent = ""));
  form.querySelectorAll(".invalid").forEach((el) => el.classList.remove("invalid"));
  Object.entries(errors).forEach(([field, message]) => {
    form.querySelector(`[data-error-for="${field}"]`).textContent = message;
    form.elements[field].classList.add("invalid");
  });
  const first = Object.keys(errors)[0];
  if (first) form.elements[first].focus();
}

async function handleFormSubmit(form) {
  const id = form.dataset.id;
  const data = {
    fullName: form.elements.fullName.value.trim(),
    email: form.elements.email.value.trim(),
    phone: form.elements.phone.value.trim(),
    address: form.elements.address.value.trim(),
    city: form.elements.city.value.trim(),
    status: form.elements.status.value,
  };

  const errors = validateCustomer(data);
  showFormErrors(form, errors);
  if (Object.keys(errors).length > 0) return;

  const button = document.getElementById("submitBtn");
  const originalLabel = button.textContent;
  button.disabled = true;
  button.textContent = "Saving...";

  try {
    if (id) {
      await api.update(id, data);
      showToast("Customer updated successfully.", "success");
    } else {
      await api.create(data);
      showToast("Customer added successfully.", "success");
    }
    location.hash = "#/customers";
  } catch (err) {
    showToast(err.message || "Could not save the customer.", "error");
    button.disabled = false;
    button.textContent = originalLabel;
  }
}

/* =====================================================
   8. EVENTS (one click handler for the whole page)
   ===================================================== */
view.addEventListener("click", (e) => {
  const el = e.target.closest("[data-action]");
  if (!el || el.disabled) return;
  const { action, id, target, page } = el.dataset;

  if (action === "goto") location.hash = target;
  else if (action === "edit") location.hash = `#/edit/${id}`;
  else if (action === "delete") deleteCustomer(id);
  else if (action === "page") { state.page = Number(page); renderTable(); }
  else if (action === "retry" && retryHandler) retryHandler();
});

view.addEventListener("submit", (e) => {
  if (e.target.id === "customerForm") {
    e.preventDefault();
    handleFormSubmit(e.target);
  }
});

// Clear a field's error message as soon as the user edits it
view.addEventListener("input", (e) => {
  const field = e.target;
  if (field.closest("#customerForm") && field.classList.contains("invalid")) {
    field.classList.remove("invalid");
    const msg = document.querySelector(`[data-error-for="${field.name}"]`);
    if (msg) msg.textContent = "";
  }
});

/* =====================================================
   9. ROUTER & SIDEBAR
   ===================================================== */
const TITLES = { dashboard: "Dashboard", customers: "Customers", add: "Add Customer", edit: "Edit Customer" };

function router() {
  const parts = (location.hash.replace(/^#\/?/, "") || "dashboard").split("/");
  const name = parts[0];
  const id = parts[1];

  if (!TITLES[name] || (name === "edit" && !id)) {
    location.hash = "#/dashboard";
    return;
  }

  pageTitle.textContent = TITLES[name];
  document.title = `${TITLES[name]} | Customer Management System`;
  document.querySelectorAll(".nav-link").forEach((link) => {
    const route = link.dataset.route;
    link.classList.toggle("active", route === name || (name === "edit" && route === "customers"));
  });
  closeSidebar();

  if (name === "dashboard") renderDashboard();
  else if (name === "customers") renderCustomers();
  else if (name === "add") renderForm();
  else if (name === "edit") renderForm(id);
}

const sidebar = document.getElementById("sidebar");
const overlay = document.getElementById("overlay");
function openSidebar()  { sidebar.classList.add("open"); overlay.classList.add("show"); }
function closeSidebar() { sidebar.classList.remove("open"); overlay.classList.remove("show"); }

document.getElementById("menuBtn").addEventListener("click", openSidebar);
overlay.addEventListener("click", closeSidebar);

/* =====================================================
   10. START THE APP
   ===================================================== */
document.querySelectorAll("[data-icon]").forEach((el) => (el.innerHTML = icon(el.dataset.icon)));

const modeBadge = document.getElementById("modeBadge");
if (CONFIG.USE_MOCK_DATA) {
  modeBadge.textContent = "Preview mode: mock data";
} else {
  modeBadge.textContent = "Using REST API";
  modeBadge.classList.add("live");
}

window.addEventListener("hashchange", router);
router();