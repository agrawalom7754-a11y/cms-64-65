CREATE DATABASE IF NOT EXISTS customer_management_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE customer_management_db;

-- Hibernate creates/updates the customers table from the Customer entity
-- when the Spring Boot application starts (ddl-auto=update).
