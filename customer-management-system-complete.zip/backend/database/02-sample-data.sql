USE customer_management_db;

-- Optional sample data. Run only if you want sample rows in the database.
-- Do not run repeatedly because email addresses are unique.
INSERT INTO customers
    (full_name, email, phone, address, city, status, created_at)
VALUES
    ('Aarav Sharma', 'aarav.sharma@example.com', '9820011122', '12 Linking Road, Bandra', 'Mumbai', 'ACTIVE', CURRENT_TIMESTAMP),
    ('Priya Nair', 'priya.nair@example.com', '9845012345', '45 MG Road', 'Bengaluru', 'ACTIVE', CURRENT_TIMESTAMP),
    ('Rohan Mehta', 'rohan.mehta@example.com', '9911223344', '8 Connaught Place', 'Delhi', 'INACTIVE', CURRENT_TIMESTAMP);
