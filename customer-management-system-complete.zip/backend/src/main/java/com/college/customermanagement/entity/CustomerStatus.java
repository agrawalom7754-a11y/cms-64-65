package com.college.customermanagement.entity;

public enum CustomerStatus {
    ACTIVE,
    INACTIVE
}
