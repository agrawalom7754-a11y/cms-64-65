package com.college.customermanagement.service;

import com.college.customermanagement.dto.CustomerRequest;
import com.college.customermanagement.dto.CustomerResponse;
import com.college.customermanagement.entity.Customer;
import com.college.customermanagement.exception.DuplicateEmailException;
import com.college.customermanagement.exception.ResourceNotFoundException;
import com.college.customermanagement.repository.CustomerRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Locale;

@Service
public class CustomerService {
    private final CustomerRepository repository;

    public CustomerService(CustomerRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public List<CustomerResponse> getAllCustomers() {
        return repository.findAll().stream()
                .map(CustomerResponse::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public CustomerResponse getCustomerById(Long id) {
        return CustomerResponse.from(findCustomer(id));
    }

    @Transactional
    public CustomerResponse createCustomer(CustomerRequest request) {
        String email = normalizeEmail(request.getEmail());
        if (repository.existsByEmailIgnoreCase(email)) {
            throw new DuplicateEmailException("A customer with this email already exists.");
        }

        Customer customer = new Customer();
        applyRequest(customer, request, email);
        try {
            return CustomerResponse.from(repository.saveAndFlush(customer));
        } catch (DataIntegrityViolationException ex) {
            throw new DuplicateEmailException("A customer with this email already exists.");
        }
    }

    @Transactional
    public CustomerResponse updateCustomer(Long id, CustomerRequest request) {
        Customer customer = findCustomer(id);
        String email = normalizeEmail(request.getEmail());

        repository.findByEmailIgnoreCase(email).ifPresent(existing -> {
            if (!existing.getId().equals(id)) {
                throw new DuplicateEmailException("A customer with this email already exists.");
            }
        });

        applyRequest(customer, request, email);
        try {
            return CustomerResponse.from(repository.saveAndFlush(customer));
        } catch (DataIntegrityViolationException ex) {
            throw new DuplicateEmailException("A customer with this email already exists.");
        }
    }

    @Transactional
    public void deleteCustomer(Long id) {
        Customer customer = findCustomer(id);
        repository.delete(customer);
    }

    private Customer findCustomer(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer with ID " + id + " was not found."));
    }

    private void applyRequest(Customer customer, CustomerRequest request, String email) {
        customer.setFullName(request.getFullName().trim());
        customer.setEmail(email);
        customer.setPhone(request.getPhone().trim());
        customer.setAddress(blankToNull(request.getAddress()));
        customer.setCity(blankToNull(request.getCity()));
        customer.setStatus(request.getStatus());
    }

    private String normalizeEmail(String email) {
        return email.trim().toLowerCase(Locale.ROOT);
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
