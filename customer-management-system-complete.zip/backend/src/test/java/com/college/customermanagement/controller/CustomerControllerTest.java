package com.college.customermanagement.controller;

import com.college.customermanagement.dto.CustomerResponse;
import com.college.customermanagement.entity.CustomerStatus;
import com.college.customermanagement.service.CustomerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CustomerController.class)
@Import(com.college.customermanagement.exception.GlobalExceptionHandler.class)
class CustomerControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private CustomerService customerService;

    @Test
    void getCustomersReturnsJsonList() throws Exception {
        CustomerResponse response = new CustomerResponse();
        response.setId(1L);
        response.setFullName("Test User");
        response.setEmail("test@example.com");
        response.setPhone("9876543210");
        response.setStatus(CustomerStatus.ACTIVE);
        response.setCreatedAt(LocalDateTime.now());
        when(customerService.getAllCustomers()).thenReturn(List.of(response));

        mockMvc.perform(get("/api/customers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].fullName").value("Test User"));
    }

    @Test
    void createCustomerRejectsInvalidEmail() throws Exception {
        String body = """
            {"fullName":"Test User","email":"not-an-email","phone":"9876543210",
             "address":"Test address","city":"Mumbai","status":"ACTIVE"}
            """;

        mockMvc.perform(post("/api/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors.email").exists());
    }
}
