package com.college.customermanagement.service;

import com.college.customermanagement.dto.CustomerRequest;
import com.college.customermanagement.dto.CustomerResponse;
import com.college.customermanagement.entity.Customer;
import com.college.customermanagement.entity.CustomerStatus;
import com.college.customermanagement.exception.DuplicateEmailException;
import com.college.customermanagement.exception.ResourceNotFoundException;
import com.college.customermanagement.repository.CustomerRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerServiceTest {
    @Mock
    private CustomerRepository repository;

    @InjectMocks
    private CustomerService service;

    @Test
    void createCustomerReturnsSavedCustomer() {
        CustomerRequest request = request("Test User", "test@example.com");
        when(repository.existsByEmailIgnoreCase("test@example.com")).thenReturn(false);
        when(repository.saveAndFlush(any(Customer.class))).thenAnswer(invocation -> {
            Customer customer = invocation.getArgument(0);
            customer.setId(1L);
            customer.setCreatedAt(LocalDateTime.now());
            return customer;
        });

        CustomerResponse response = service.createCustomer(request);

        assertEquals(1L, response.getId());
        assertEquals("Test User", response.getFullName());
        assertEquals("test@example.com", response.getEmail());
        verify(repository).saveAndFlush(any(Customer.class));
    }

    @Test
    void createCustomerRejectsDuplicateEmail() {
        when(repository.existsByEmailIgnoreCase("test@example.com")).thenReturn(true);

        assertThrows(DuplicateEmailException.class,
                () -> service.createCustomer(request("Test User", "test@example.com")));
        verify(repository, never()).saveAndFlush(any(Customer.class));
    }

    @Test
    void getMissingCustomerThrowsNotFound() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getCustomerById(99L));
    }

    private CustomerRequest request(String name, String email) {
        CustomerRequest request = new CustomerRequest();
        request.setFullName(name);
        request.setEmail(email);
        request.setPhone("9876543210");
        request.setAddress("Test address");
        request.setCity("Mumbai");
        request.setStatus(CustomerStatus.ACTIVE);
        return request;
    }
}
