package com.college.customermanagement;

import com.college.customermanagement.dto.CustomerRequest;
import com.college.customermanagement.dto.CustomerResponse;
import com.college.customermanagement.entity.CustomerStatus;
import com.college.customermanagement.repository.CustomerRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class CustomerApiIntegrationTest {
    @Autowired private MockMvc mockMvc;
    @Autowired private ObjectMapper objectMapper;
    @Autowired private CustomerRepository customerRepository;

    @BeforeEach
    void cleanDatabase() {
        customerRepository.deleteAll();
    }

    @Test
    void createThenFetchCustomer() throws Exception {
        CustomerRequest request = new CustomerRequest();
        request.setFullName("Integration User");
        request.setEmail("integration@example.com");
        request.setPhone("9876543210");
        request.setAddress("Test address");
        request.setCity("Mumbai");
        request.setStatus(CustomerStatus.ACTIVE);

        String responseBody = mockMvc.perform(post("/api/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.email").value("integration@example.com"))
                .andReturn().getResponse().getContentAsString();

        CustomerResponse created = objectMapper.readValue(responseBody, CustomerResponse.class);

        mockMvc.perform(get("/api/customers/{id}", created.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fullName").value("Integration User"));
    }
}
